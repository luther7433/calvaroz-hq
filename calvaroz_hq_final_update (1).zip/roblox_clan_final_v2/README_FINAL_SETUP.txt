CALVAROZ HQ FINAL UPDATE
========================
Already configured:
- Group ID: 34922741
- Group URL: https://www.roblox.com/communities/34922741/Calvaroz#!/about
- Calvaroz eagle logo
- Live group member count
- Live Roblox group role order
- Click/hover UI audio clips extracted from the uploaded reference video
- Animated futuristic background + particle field
- Clickable Calvaroz logo/buttons to the Roblox group

FILES:
public/index.html
public/css/style.css
public/js/main.js
public/assets/img/calvaroz-logo.png
public/assets/sfx/click.mp3
public/assets/sfx/hover.mp3
server/server.js
package.json

RUN:
1. Replace your old public/index.html with this one.
2. Replace public/css/style.css.
3. Replace public/js/main.js.
4. Replace server/server.js.
5. Copy public/assets/img/calvaroz-logo.png.
6. Copy public/assets/sfx/click.mp3 and hover.mp3.
7. Replace package.json if desired.
8. In terminal:
   npm install
   npm start
9. Open http://localhost:3000

EASY EDIT:
- Group connection: public/js/main.js -> SITE_CONFIG GROUP_ID/GROUP_URL
  and server/server.js -> GROUP_ID.
- Organization: public/js/main.js -> ORGANIZATION.
- Manual CP/Merit/Stats: public/js/main.js -> PLAYER_DATA.
- Manual CP per rank: public/js/main.js -> RANK_REQUIREMENTS. Leave a rank out to use 300 CP.
- Medals: public/js/main.js -> MEDALS.
- Uniforms: public/js/main.js -> UNIFORMS.
- Blacklist: public/js/main.js -> BLACKLIST.
- Clan name/tagline: public/js/main.js -> CLAN_NAME/CLAN_SHORT_NAME/TAGLINE.
- Logo file: public/assets/img/calvaroz-logo.png

LIVE DATA:
The website requests the Roblox group endpoint on startup and refreshes it every 60 seconds. The member count is not taken from PLAYER_DATA. The ranks page is replaced by the actual Roblox group roles and ordered by Roblox's numeric rank.

IMPORTANT:
The CP/Merit/Stats system remains manual because Roblox group roles do not contain your clan's custom CP/Merit database. You can later connect those fields to a database/Open Cloud service.

The reference video was used to match the dark/red futuristic direction and to extract short UI sound clips. The implementation is an original Calvaroz design, not a byte-for-byte copy of the reference site's code/assets.
